package test_maven.test_maven;

import java.io.InputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class DownloadFileTests  {
	static String email;
	static String password;
	
	public static void main(String[] args) throws Exception
	{
		//Below code to Open execute the chrome driver and launch the URL
		
		System.setProperty("webdriver.chrome.driver", "/Users/akankshashrivastava/Downloads/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://accounts.google.com/ServiceLogin/signinchooser?service=wise&passive=true&continue=http%3A%2F%2Fdrive.google.com%2F%3Futm_source%3Den&utm_medium=button&utm_campaign=web&utm_content=gotodrive&usp=gtd&ltmpl=drive&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
		
		driver.findElement(By.name("identifier")).sendKeys(email);
		
		driver.findElement(By.className("VfPpkd-vQzf8d")).click();
		
		driver.findElement(By.className("password")).sendKeys(password);
		
		driver.findElement(By.cssSelector("Next")).click();
		
		
		//To Download File from Google Drive
		public InputStream download(String id) throws CloudServiceException {
		    try {
		        File file = service.files()
		                .get(id)
		                .execute();
		        String link = file.getExportLinks().get("test/docx");
		        HttpResponse resp = service.getRequestFactory()
		                .buildGetRequest(
		                        new GenericUrl(link))
		                .execute();
		        return resp.getContent();
		    } catch (HttpResponseException e) {
		        throw CloudServiceExceptionTransformer.transform(e, e.getStatusCode());
		    } catch(IOException ex) {
		        throw new InternalException(ex);
		      
		    }
		}
		
		
	}
	
	

}
